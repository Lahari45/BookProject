myApp.controller("EditController",function($scope){

})