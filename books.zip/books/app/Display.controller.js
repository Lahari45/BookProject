myApp.controller("DisplayController",function($scope){

    $scope.content="Book Details";

    $scope.bookArr=[

    {BookId:500,BookName:"Harry Potter and the Sorcerer's Stone",image:'D:\Harrypart1.jpg',Author:"J.K.Rowling",

    Description:"Just before Harry's eleventh birthday, owls begin delivering letters addressed to him. When the abusive Dursleys refuse to allow Harry to open any, Hagrid arrives to personally deliver Harry's letter. Harry is a wizard and has been accepted to Hogwarts.",price:500},

    {BookId:501,BookName:"Harry Potter and the Chamber of Secrets",image:"D:\Harrypart2.jpg",Author:"J.K.Rowling",

    Description:"Spending the summer with the Dursleys, Harry Potter meets Dobby, a house-elf who warns him that it is too dangerous to return to Hogwarts. Dobby sabotages an important dinner for the Dursleys, who lock Harry up to prevent his return to Hogwarts.",price:200},

    {BookId:502,BookName:"Harry Potter and the Prisoner of Azkaban",image:"D:\Harrypart3.jpg",Author:"J.K.Rowling",

    Description:"During a summer with the Dursleys, Harry Potter loses his temper and inadvertently causes Aunt Marge Dursley to inflate like a balloon and float away when the latter insults his parents. Fed up, Harry then flees the Dursleys with his belongings. The Knight Bus arrives and takes Harry to the Leaky Cauldron, where he is pardoned by Minister for Magic Cornelius Fudge for using magic outside of Hogwarts.",price:700},

    {BookId:503,BookName:"Harry Potter and the Goblet of Fire",image:"D:\Harrypart4.jpg",Author:"J.K.Rowling",

    Description:"Harry Potter has a nightmare wherein a Muggle caretaker named Frank Bryce is killed after overhearing Lord Voldemort conspiring with Peter Pettigrew and another man. Harry attends the Quidditch World Cup with the Weasleys and Hermione, during which Death Eaters terrorise the camp. The same man who appeared in Harry's dream conjures the Dark Mark.",price:1000}];

    $scope.selectedBook={};

    $scope.showEditBook=false;
    $scope.editBookEventHandler=function(obj){
        $scope.selectedBook=obj;
        alert("Do u want to edit" + obj.BookId + "");
        $scope.showEditBook=true;
    }
    $scope.showAddBook=false;
    $scope.addNewBookEventHandler=function()
    {    
        $scope.showAddBook=true;

    }

    $scope.$on("Addnewbook",function(event,newBook){

        console.log(newBook);

        $scope.bookArr.push(newBook); 

        $scope.showAddBook=false; 

    }) 

    $scope.$on("cancelAddnewBook",function(){

        $scope.showAddBook=false;

    })

    $scope.deleteBookEventHandler=function(bookToBeDeleted)

    {

        var pos=$scope.bookArr.findIndex(item=> {

            if(item.BookId == bookToBeDeleted.BookId)

            {
                return true;

            }

            else

            {

                return false;

            }

        })

        $scope.bookArr.splice(pos,1);

        console.log(bookToBeDeleted);

    }
    $scope.saveEditBookDetailsEventHandler = function()

    {

        $scope.showEditBook=false;

    }

})